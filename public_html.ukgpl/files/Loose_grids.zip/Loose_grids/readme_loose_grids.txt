This zip file contains a compilation of modified track.ini files which have been tested in several league I host. They are mostly 1 x 1 staggered grids for really easy online starts.

Let me know if there are any problems with them.

Paul Jackson
October 17th, 2002
paulj@m2mag.com

Updates:

2002/10/31 - Donington National added

2003/12/16 - 32 NEW FILES ADDED

2004/03/23 - 4 NEW FILES ADDED

Tracks included now:

Adelaide
Aintree
Albi67
AssenTT
Anderstorp
Avus59
Avus67 (when its released)
BA15
Barber
Beal
Blue Mountain
Bottomless Lakes
Brands Hatch (Noonan)
Brands67
Bremgarten
LeMans Sarthe
LeMans Bugatti
Castle Combe
Charade 1970
Cilce
Croft 67
Crystal Palace
Diamante
Donington National
East London
Efexx Club Circuit
Estoril
Falkenbergs Motorbana
Gingerman
Goodwood
Grenzlandring
Halle Saale Schliefe
Hockenheim 1970
Hockenheim 1967
Interlagos 1973
Imola
Inianapolis (N3)
Indy 1967
Jamaica
Jim (Neuvil Klubrennen)
Keimola
Kyalami
Laguna Seca 1967
Laguna Seca 1995
Lakeside 1967
Landmark 
Leipzig
Lime Rock Mountain Course
Lime Rock Park (Chicane)
Mallory Park
Mexico City
Milano
Sepang
Monaco
Montrevault
Monza
Mosport
Nivelles
NorisRing
Nurburgring
Oulton 60s
Panorama
Parque Independencia
Pau 1967
Pebble Beach
Pic Long
Pic Midi
Polar Bear
Reims
Road Atlanta
Road Ontario
Rolex (Daytona)
Rouen
Sachsenring 1967
Salzburgring 1974
Salzburgring 1976
Sandown
Schottenring
Sebring 1960
Silverstone
Snetterton 1967
Solitude 
Spa 
St. Jovite
Suzuka 2000
Suzuka 1978
Syracuse
Thornham
Thruxton
Riverside 1960
Usui
Vanring
Virginia
Watkins Glen 1967
Watkins Glen 1971
Watkins Glen 1948
Wild South Raceway
Zandvoort
Zetlweg 1970
Zolder