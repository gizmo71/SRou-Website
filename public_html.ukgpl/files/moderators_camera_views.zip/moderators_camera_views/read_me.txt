In each of the car directories that contains a .dat file, copy the asssociated .cam file into the directory (overwriting the existing .cam file as necessary).

For example in the 66mod carset copy the c12.cam file into the c12 directory (there should be no file to overwrite in this case) to change the camera views for the Maclaren.