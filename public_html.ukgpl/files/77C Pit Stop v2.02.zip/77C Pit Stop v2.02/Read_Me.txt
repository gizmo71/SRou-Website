Installation Instructions

The file "Pitstop Handicap Manager.exe" must be saved to your GPL installation folder (normally C:\Sierra\GPL ).
You may find it convenient to create a shortcut on your desktop.

The files "77C Pit Stop v2.02.xml" and "78X KeyPress v.08.xml" must be saved to "Options" folder in your GEM+ installation (normally C:\GPLSecrets\GEM+\Options ).

Another copy of the file "77C Pit Stop v2.02.xml" must be saved to your GPL installation folder (normally C:\Sierra\GPL ).

Run the "Pitstop Handicap Manager.exe" and it will prompt you for the path to your GPLSecrets folder (normally C:\GPLSecrets).

When the "Pitstop Handicap Manager.exe" runs, it creates a file called "Pitstop Handicap Settings.ini" in your GPL installation folder. Do not try to edit this file to set the handicap time, it will have no effect.